package com.example.recommender;

import java.io.File;
import java.util.List;


public class RecommenderDemo {


public static void main(String[] args) throws Exception {
// data file (userID, itemID, preference)
String dataFile = "src/main/resources/data.csv";
if (args.length >= 1) dataFile = args[0];


DataModel model = new FileDataModel(new File(dataFile));


UserSimilarity similarity = new PearsonCorrelationSimilarity(model);
UserNeighborhood neighborhood = new NearestNUserNeighborhood(2, similarity, model);


Recommender recommender = new GenericUserBasedRecommender(model, neighborhood, similarity);


// Example: recommend for user 1
int userId = 1;
if (args.length >= 2) {
try { userId = Integer.parseInt(args[1]); } catch (NumberFormatException ignored) {}
}


List<RecommendedItem> recommendations = recommender.recommend(userId, 5);


System.out.println("Recommendations for user " + userId + ":");
if (recommendations.isEmpty()) System.out.println(" (no recommendations)");
for (RecommendedItem ri : recommendations) {
System.out.println(" Item: " + ri.getItemID() + " -> Estimated preference: " + ri.getValue());
}
}
}